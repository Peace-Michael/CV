// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title  PatientRecordContract
 * @notice A smart contract for managing patient medical records on the
 *         Ethereum blockchain.
 *

 *         
 */
contract PatientRecordContract {

   
    // STRUCTS
    

    /**
     * @dev PatientRecord holds the minimum viable information needed to
     *      track a patient record on-chain.
     */
    struct PatientRecord {
        uint256 recordId;           // auto-incremented unique ID
        string  patientName;        // patient name or pseudonym
        string  diagnosis;          // clinical summary / IPFS CID in production
        address custodian;          // current responsible provider
        bool    exists;             // guard against uninitialised reads
        uint256 createdAt;          // block.timestamp at creation
        uint256 updatedAt;          // block.timestamp of last transfer
    }

 
    // STATE VARIABLES


    /// @notice Total number of records ever created .
    uint256 public totalRecords;

    /// @notice Address of the contract deployer; controls provider authorisation.
    address public owner;

    /// @dev Maps an Ethereum address to its provider authorisation status.
    mapping(address => bool) public authorisedProviders;

    /// @dev Maps a record ID to its PatientRecord struct.
    mapping(uint256 => PatientRecord) private records;

   
    // EVENTS
 

    /**
     * @dev Emitted when the owner authorises a new healthcare provider.
     * @param provider  The newly authorised Ethereum address.
     */
    event ProviderAuthorised(address indexed provider);

    /**
     * @dev Emitted when a new patient record is added to the contract.
     * @param recordId      The auto-generated record ID.
     * @param patientName   The patient's name / identifier.
     * @param custodian     The provider that created the record.
     */
    event RecordAdded(
        uint256 indexed recordId,
        string patientName,
        address indexed custodian
    );

    /**
     * @dev Emitted when a record's custodian is changed (transferred).
     * @param recordId      The record that was transferred.
     * @param from          The previous custodian.
     * @param to            The new custodian.
     */
    event RecordTransferred(
        uint256 indexed recordId,
        address indexed from,
        address indexed to
    );

    
    // MODIFIERS
    

    /**
     * @dev Restricts a function to the contract owner only.
     *      Used for administrative operations like authorising providers.
     */
    modifier onlyOwner() {
        require(msg.sender == owner, "Caller is not the contract owner");
        _;
    }

    /**
     * @dev Restricts a function to addresses in the authorisedProviders mapping.
     *      This is the primary access-control gate for record operations.
     */
    modifier onlyAuthorised() {
        require(
            authorisedProviders[msg.sender],
            "Caller is not an authorised healthcare provider"
        );
        _;
    }

    /**
     * @dev Ensures a record with the given ID actually exists before
     *      attempting to read or modify it.
     */
    modifier recordExists(uint256 recordId) {
        require(records[recordId].exists, "Record does not exist");
        _;
    }

    // CONSTRUCTOR
   

    /**
     * @notice Deploys the contract and records the deployer as owner.
     *         The owner is automatically granted provider rights.
     */
    constructor() {
        owner = msg.sender;
        authorisedProviders[msg.sender] = true;
        totalRecords = 0;
        emit ProviderAuthorised(msg.sender);
    }

   
    // ADMINISTRATIVE FUNCTIONS
    

    /**
     * @notice Authorise a new healthcare provider address.
     * @dev    Only the owner can call this.  Once authorised, the provider
     *         can add and transfer records.
     * @param  provider  The Ethereum address of the healthcare provider.
     */
    function authoriseProvider(address provider) external onlyOwner {
        require(provider != address(0), "Invalid address");
        require(!authorisedProviders[provider], "Provider already authorised");
        authorisedProviders[provider] = true;
        emit ProviderAuthorised(provider);
    }

    
    // CORE RECORD FUNCTIONS

    /**
     * @notice Add a new patient record to the blockchain.
     * @dev    Increments totalRecords before storing so IDs start at 1.
     *         The calling provider becomes the initial custodian.
     *
     * @param  patientName  The patient's name or anonymised identifier.
     * @param  diagnosis    Clinical summary or IPFS content hash.
     * @return newId        The auto-generated record ID.
     */
    function addRecord(
        string calldata patientName,
        string calldata diagnosis
    ) external onlyAuthorised returns (uint256 newId) {
        totalRecords += 1;
        newId = totalRecords;

        records[newId] = PatientRecord({
            recordId:    newId,
            patientName: patientName,
            diagnosis:   diagnosis,
            custodian:   msg.sender,
            exists:      true,
            createdAt:   block.timestamp,
            updatedAt:   block.timestamp
        });

        emit RecordAdded(newId, patientName, msg.sender);
        return newId;
    }

    /**
     * @notice Transfer custodianship of a record to another authorised provider.
     * @dev    Only the *current* custodian may transfer; this prevents
     *         unauthorised providers from seizing records.
     *
     * Security consideration: restricting transfer to the current custodian
     * mirrors real-world consent models where only the holding provider can
     * share a patient's records.
     *
     * @param  recordId     The ID of the record to transfer.
     * @param  newCustodian The Ethereum address of the receiving provider.
     */
    function transferRecord(
        uint256 recordId,
        address newCustodian
    ) external onlyAuthorised recordExists(recordId) {
        PatientRecord storage rec = records[recordId];

        require(
            rec.custodian == msg.sender,
            "Only the current custodian can transfer this record"
        );
        require(
            authorisedProviders[newCustodian],
            "Recipient is not an authorised provider"
        );
        require(newCustodian != msg.sender, "Cannot transfer to yourself");

        address previousCustodian = rec.custodian;
        rec.custodian = newCustodian;
        rec.updatedAt = block.timestamp;

        emit RecordTransferred(recordId, previousCustodian, newCustodian);
    }

    
    // VIEW / QUERY FUNCTIONS

    /**
     * @notice Retrieve all details for a given record ID.
     * @dev    Public visibility – any address can read (transparent ledger).
     *         In a production system, sensitive fields would be encrypted or
     *         replaced by IPFS CIDs.
     *
     * @param  recordId  The ID of the record to look up.
     * @return The full PatientRecord struct.
     */
    function getRecord(uint256 recordId)
        external
        view
        recordExists(recordId)
        returns (PatientRecord memory)
    {
        return records[recordId];
    }

    /**
     * @notice Check whether a given address is an authorised provider.
     * @param  provider  Address to check.
     * @return True if authorised, false otherwise.
     */
    function isAuthorised(address provider) external view returns (bool) {
        return authorisedProviders[provider];
    }
}
